<?php include 'header.php'; ?>

<section class="container-fluid home-banner">
    <video loop="" muted="" autoplay="" poster="#" class="background-video">
        <source width="100%" src="./assets/video/home-banner.mp4" type="video/mp4">
    </video>
    <div class="home-banner-overlay-main"></div>
    <div class="container">
        <div id="carouselExampleSlidesOnly" class="carousel slide banner-slide-padding" data-bs-ride="carousel"
            data-bs-interval="5000">
            <div class="carousel-inner">

                <div class="carousel-item active">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-12 text-center">
                            <span class="banner-heading text-capitalize">Count on Us for Elite Book Writing
                                services</span>
                            <p class="quotes">For professional writing partners, look no further than Elite Book
                                Writers. We offer a
                                wide range of writing services that suit your needs. Any aspiring poet, children's book
                                author, or
                                novelist can benefit from our knowledge and resources.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="carousel-item">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-12 text-center">
                            <span class="banner-heading text-capitalize">Step into the World of Writing</span>
                            <p class="quotes">Elite book writers are your ticket to author success. To help you realize
                                your
                                literary goals, we provide a range of book writing services, including marketing,
                                editing, author
                                websites, and more.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="carousel-item">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-12 text-center">
                            <span class="banner-heading text-capitalize">Transforming Ideas into #1 bestsellers</span>
                            <p class="quotes">Everyone must hear your story. Our creative book writers in-depth
                                understanding of the
                                industry allows us to transform your manuscript into a captivating best-seller.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="carousel-item">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-12 text-center">
                            <span class="banner-heading text-capitalize">Visualizing Your Creativity</span>
                            <p class="quotes">Add plenty of stunning images to your book. With the help of our
                                professional book
                                writers illustration services, your words will take on a whole new meaning and become
                                truly
                                irresistible.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="carousel-item">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-12 text-center">
                            <span class="banner-heading text-capitalize">Where Life-Changing Tales Begin</span>
                            <p class="quotes">Work with Elite Books Writers to unlock your full literary potential—our
                                best book
                                writing service covers every stage, from manuscript to masterpiece.
                            </p>
                        </div>
                    </div>
                </div>

                <div class="carousel-item">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-12 text-center">
                            <span class="banner-heading text-capitalize">Shaping Words to Create Realities</span>
                            <p class="quotes">Our team of book writers creates unique stories. Take a look at our
                                professional book
                                writing company offers, from writing books to illustrating them professionally.
                            </p>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <form method="post" action="code.php">
            <div class="row justify-content-center align-items-center pt-3 ">
                <div class="col-lg-8 mx-auto">
                    <div class="row justify-content-center align-items-center banner-form-shadow">
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 px-0">
                            <div class="form-floating">
                                <input type="text" class="form-control form-radius-left" name="h-name"
                                    id="floatingFname" placeholder="First Name" required>
                                <label for="floatingFname">Full Name</label>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 px-0 ">
                            <div class="form-floating">
                                <input type="email" class="form-control form-control-radius form-radius-right2"
                                    name="h-email" id="floatingEmail" placeholder="Email Address" required>
                                <label for="floatingEmail">Email address</label>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 px-0 ">
                            <div class="form-floating">
                                <input type="number" class="form-control form-control-radius form-radius-left2"
                                    name="h-phone" id="floatingPhone" placeholder="Phone Number" required>
                                <label for="floatingPhone">Phone Number</label>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 px-0">
                            <button class="banner-btn form-control form-radius-right" type="submit"
                                name="home-submit">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>

        <div class="row">
            <div class="col-12 text-center my-4">
                <p class="text-white m-0">Rated 9.1 out of 10 <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span> based on 3428 satisfied customers
                </p>
            </div>

            <div class="col-12 text-center mt-3">
                <h4 style="color: #f19102 !important;">Setting the Standard Since 2015 EliteBookWriters Where Quality
                    Meets Expertise</h4>
            </div>
        </div>
    </div>
</section>


<section class="container-fluid section-banner">


    <div class="container pb-5">
        <div class="row justify-content-center align-items-center border border-warning border-2 rounded-5">
            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-4 col-xs-12 my-4 text-center">
                <a href="https://www.amazon.com/" target="_blank">
                    <img src="./assets/images/amazon.svg" alt="">
                </a>
            </div>

            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-4 col-xs-12 my-4 text-center">
                <a href="https://www.barnesandnoble.com/" target="_blank">
                    <img src="./assets/images/barnes.svg" alt="">
                </a>
            </div>

            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-4 col-xs-12 my-4 text-center">
                <a href="https://www.amazon.com/s?k=kindle+bookstore&adgrpid=155902181518&hvadid=678787405666&hvdev=c&hvlocphy=9077134&hvnetw=g&hvqmt=b&hvrand=8055484549543644341&hvtargid=kwd-4404045442&hydadcr=21183_13499917&tag=hydglogoo-20&ref=pd_sl_164dce15jq_b"
                    target="_blank">
                    <img src="./assets/images/kindle.svg" alt="">
                </a>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="row justify-content-around align-items-start">
            <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6 border-end ">
                <p><b>Our book writers will partner with
                        you to create a masterpiece in each chapter.
                    </b></p>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-8 col-xs-6">
                <div class="row justify-content-around align-items-center">
                    <div class="col-lg-2 col-md-3 col-sm-6 col-xs-6 extra-small"><a
                            href="https://www.apple.com/apple-books/"><img width="100%" src="./assets/images/ibook.png"
                                alt=""></a></div>
                    <div class="col-lg-2 col-md-3 col-sm-6 col-xs-6 extra-small"><a
                            href="https://play.google.com/store/apps"><img width="100%"
                                src="./assets/images/Google-Play.svg" alt=""></a></div>
                    <div class="col-lg-2 col-md-3 col-sm-6 col-xs-6 extra-small"><a href="https://www.kobo.com/"><img
                                width="100%" src="./assets/images/Kobo-logo.png" alt=""></a></div>
                    <div class="col-lg-2 col-md-3 col-sm-6 col-xs-6 extra-small"><a href="https://www.scribd.com/"><img
                                width="100%" src="./assets/images/Scribd-logo.svg" alt=""></a></div>
                </div>
            </div>
        </div>
    </div>


    <div class="container py-3 border-top">
        <div class="row justify-content-around align-items-center">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                <div class="d-flex justify-content-center align-items-center">
                    <img width="60px" src="./assets/images/client-satisfaction.webp" alt="">
                    <p class="line-heights">Customer Satisfaction is Our Priority</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                <div class="d-flex justify-content-center align-items-center">
                    <img width="60px" src="./assets/images/serving-clients-across.webp" alt="">
                    <p class="line-heights">Global clients 10378 and Expanding </p>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                <div class="d-flex justify-content-center align-items-center">
                    <img width="60px" src="./assets/images/amazing-rates.webp" alt="">
                    <p class="line-heights">Fair Price With Money Back Guarantee</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
                <div class="d-flex justify-content-center align-items-center">
                    <img width="60px" src="./assets/images/incredible-sales.webp" alt="">
                    <p class="line-heights">Anonymity 100%</p>
                </div>
            </div>
        </div>
    </div>


    <div class="container py-5">
        <div class="row">
            <div class="col-12">
                <h2 class="text-center pt-4">GET PREMIUM BOOK PROMOTION</h2>
            </div>
        </div>
        <div class="row justify-content-center align-items-center isbn-service">

            <div class="col-lg-8 col-md-9 col-sm-10 col-xs-12 mt-4">
                <div class="row justify-content-center align-items-center isbn-service-box">
                    <div class="col-lg-2 col-md-2 col-sm-3 col-xs-3 mb-3 mx-auto"><img
                            src="./assets/images/with-our-book-license.svg" alt=""></div>
                    <div class="col-lg-10 col-md-10 col-sm-9 col-xs-12 mx-auto">
                        <p class="m-0">With our book license service, you can concentrate on writing while we handle the
                            legal details.</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-8 col-md-9 col-sm-10 col-xs-12 mt-4">
                <div class="row justify-content-center align-items-center isbn-service-box">
                    <div class="col-lg-2 col-md-2 col-sm-3 col-xs-3 mb-3 mx-auto"><img
                            src="./assets/images/once-your-book.svg" alt=""></div>
                    <div class="col-lg-10 col-md-10 col-sm-9 col-xs-12 mx-auto">
                        <p class="m-0">Once your book is out, use our Post-Publication marketing strategis to reach a
                            wider audience. We will customize our strategy to attract the ideal readers for your book.
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-lg-8 col-md-9 col-sm-10 col-xs-12 mt-4">
                <div class="row justify-content-center align-items-center isbn-service-box">
                    <div class="col-lg-2 col-md-2 col-sm-3 col-xs-3 mb-3 mx-auto"><img
                            src="./assets/images/count-on-our.svg" alt=""></div>
                    <div class="col-lg-10 col-md-10 col-sm-9 col-xs-12 mx-auto">
                        <p class="m-0">Count on our experienced book writers to assist you every step of the way as you
                            publish. If you want your book to be a bestseller, we can make it happen.</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-8 col-md-9 col-sm-10 col-xs-12 mt-4">
                <div class="row justify-content-center align-items-center isbn-service-box">
                    <div class="col-lg-2 col-md-2 col-sm-3 col-xs-3 mb-3 mx-auto"><img
                            src="./assets/images/as-an-authorized.svg" alt=""></div>
                    <div class="col-lg-10 col-md-10 col-sm-9 col-xs-12 mx-auto">
                        <p class="m-0">As an authorized US ISBN service provider, we provide discounted ISBNs and
                            publishing services to guarantee global recognition for your publication. We will ensure
                            that your book is identified correctly so readers can quickly discover it.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container-fluid custom-bg">
        <div class="row justify-content-center align-items-center">
            <div class="col-xl-7 col-lg-10 col-md-8 col-sm-11 mx-auto custom-bg-box">
                <h5 class="text-uppercase" style="color: #febd69 !important;">Focus on the Impact of Your Story with
                </h5>
                <h1>EXPERTS IN BOOK WRITING AT A LOW COST!</h1>
                <p class="text-white">Do you need a book writing company simply
                    because you
                    are an experienced writer or an aspiring author
                    looking for guidance?</p>
                <p class="text-white">Our professional book writing company offers
                    both traditional
                    and digital authors outstanding support
                    with book writing. The world needs to hear your tale; we can help you do that.</p>
                <div class="text-center ">
                    <a href="javascript:;" onclick="document.getElementById('overlayModal').style.display='block'">
                        <button class="header-btn" style="background-color: #0077b5;"><span>Start Writing Book With
                                Us</span></button>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="container py-5 ">
        <div class="row justify-content-center align-items-center pt-3">
            <div class="col-12 text-center">
                <h5 class="service-box">Building Trust and Confidence</h5>
                <h1>Fostering Trust on Top Review Platforms</h1>
                <div class="text-contact-border mx-auto"></div>
                <p class="w-75 mx-auto mt-4">We've earned the trust of our customers through positive reviews on
                    platforms like Google Reviews, Trustpilot, and Reviews.io. These reviews reflect the satisfaction of
                    many satisfied clients and demonstrate our dedication to excellent service.</p>
            </div>
        </div>

        <div class="row justify-content-around  align-items-center">
            <div class="col-xl-2 col-lg-4 col-md-4 col-sm-5 col-xs-12 mx-1 text-center trust-reviews my-3 p-0">
                <div class="trust-reviews-inner-border py-3">
                    <img width="100px" src="./assets/images/google-review.svg" alt="">
                    <h5>Google Reviews</h5>
                    <h3>4.5/5</h3>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star-half-stroke text-warning"></span>
                </div>
            </div>

            <div class="col-xl-2 col-lg-4 col-md-4 col-sm-5 col-xs-12 mx-1 text-center trust-reviews my-3 p-0">
                <div class="trust-reviews-inner-border py-3">
                    <img width="100px" src="./assets/images/trustpilot.svg" alt="">
                    <h5>Trustpilot</h5>
                    <h3>4.6/5</h3>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star-half-stroke text-warning"></span>
                </div>
            </div>

            <div class="col-xl-2 col-lg-4 col-md-4 col-sm-5 col-xs-12 mx-1 text-center trust-reviews my-3 p-0">
                <div class="trust-reviews-inner-border py-3">
                    <img width="100px" src="./assets/images/clutch.svg" alt="">
                    <h5>Clutch</h5>
                    <h3>5/5</h3>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span>
                </div>
            </div>

            <div class="col-xl-2 col-lg-4 col-md-4 col-sm-5 col-xs-12 mx-1 text-center trust-reviews my-3 p-0">
                <div class="trust-reviews-inner-border py-3">
                    <img width="100px" src="./assets/images/reviews.io.svg" alt="">
                    <h5>Reviews.io</h5>
                    <h3>4.7/5</h3>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star text-warning"></span>
                    <span class="fa fa-star-half-stroke text-warning"></span>
                </div>
            </div>
        </div>
    </div>

    <div class="container py-5">
        <div class="row">
            <div class="col-12">
                <h2 class="text-center">We are the best in all aspects of book writing service. A Safe Haven in the USA
                    for Writers Seeking
                    for Exceptional Expertise!</h2>
            </div>
        </div>
        <div class="row book-sec-control justify-content-center ">

            <div class="left-arrowed"><i class="fa-solid fa-circle-arrow-left"></i></div>
            <div class="right-arrowed"><i class="fa-solid fa-circle-arrow-right"></i></div>

            <div class="row justify-content-center book-sec-slide">
                <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12 text-center ">
                    <div>
                        <img class="mx-auto" width="80%" src="./assets/images/book-writing.webp" alt="">
                    </div>
                    <h4>Book Writing</h4>
                    <p>Page by page, we craft captivating tales</p>
                    <div class="para-border-center mb-4"></div>
                    <div>
                        <img class="mx-auto" width="30px" src="./assets/images/chat-with-us.webp" alt="">
                    </div>
                    <h5>Chat with us</h5>
                    <p>For any query</p>
                </div>

                <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12 text-center ">
                    <div>
                        <img class="mx-auto" width="80%" src="./assets/images/ghost-writing.webp" alt="">
                    </div>
                    <h4>Ghost Writing</h4>
                    <p>Our words, your story, and your success.</p>
                    <div class="para-border-center mb-4"></div>
                    <div class="text-center">
                        <img class="mx-auto" width="30px" src="./assets/images/discount-offers.webp" alt="">
                    </div>
                    <h5>Discount Offers</h5>
                    <p>Get up to 50% Discount</p>
                </div>

                <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12 text-center ">
                    <div>
                        <img class="mx-auto" width="80%" src="./assets/images/book-marketing.webp" alt="">
                    </div>
                    <h4>Book Marketing</h4>
                    <p>Make your book a bestseller</p>
                    <div class="para-border-center mb-4"></div>
                    <div class="text-center">
                        <img class="mx-auto" width="30px" src="./assets/images/writing-experts.webp" alt="">
                    </div>
                    <h5>Writing Experts</h5>
                    <p>Where Imagination and Excellence Blend!</p>
                </div>

                <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12 text-center ">
                    <div>
                        <img class="mx-auto" width="80%" src="./assets/images/book-publishing.webp" alt="">
                    </div>
                    <h4>Book Publishing</h4>
                    <p>Fulfilling your dreams</p>
                    <div class="para-border-center mb-4"></div>
                    <div class="text-center">
                        <img class="mx-auto" width="30px" src="./assets/images/seek-guidance.webp" alt="">
                    </div>
                    <h5>Seek Guidance</h5>
                    <p>24/7 Professional Assistance</p>
                </div>

                <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12 text-center ">
                    <div>
                        <img class="mx-auto" width="80%" src="./assets/images/book-cover-design.webp" alt="">
                    </div>
                    <h4>Book Cover Design</h4>
                    <p>A single glance captivates readers</p>
                    <div class="para-border-center mb-4"></div>
                    <div class="text-center">
                        <img class="mx-auto" width="30px" src="./assets/images/book-marketing-icon.png" alt="">
                    </div>
                    <h5>Book Marketing</h5>
                    <p> Grow audience and sales with Book Marketing</p>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid ads">
        <div class="container ">
            <div class="row justify-content-center align-items-center">
                <div class="col-lg-4 col-md-6 col-sm-12 border-end my-2">
                    <p class="fw-bold text-white text-center">Take advantage of print-on-demand best book writing
                        services by joining our top book-writing
                        agency today!</p>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 border-end my-2">
                    <div class="row justify-content-center align-items-center">
                        <div class="col-lg-3 col-md-3 col-sm-2 col-xs-3  text-center">
                            <img width="100%" src="./assets/images/Write Your Next Book.webp" alt="">
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-10 col-xs-12 text-center">
                            <h5 class="fw-bolder text-white ">Write Your Next Book with Us!</h5>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12 col-sm-12 my-2 text-center">
                    <a href="javascript:;" onclick="document.getElementById('overlayModal').style.display='block'">
                        <button class="header-btn" style="background-color: #0077b5;"><span>Avail 50%
                                Discount</span></button>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="container sec4 py-5">
        <div class="row justify-content-center align-items-center ">
            <div class="col-lg-7 col-md-10 col-sm-10 col-xs-10">
                <h5 class="text-uppercase ">Crafting Stories That Leave an Impact</h5>
                <h2>Why We Can Be the Ideal Writing Partner for You!</h2>
                <div class="para-border-left"></div>
                <p><b class="my-5">Our professional online book writers have a deep knowledge of the writing world to
                        ensure you get the proper guidance at every turn. Here are a few examples of our specialized
                        samples:</b></p>
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="d-flex align-items-center ">
                            <i class="fa-regular fa-circle-check"></i>
                            <p class="ps-2  m-0">Book Writing</p>
                        </div>
                        <div class="d-flex align-items-center ">
                            <i class="fa-regular fa-circle-check"></i>
                            <p class="ps-2  m-0">Ghost Writing</p>
                        </div>
                        <div class="d-flex align-items-center ">
                            <i class="fa-regular fa-circle-check"></i>
                            <p class="ps-2  m-0">Book Marketing</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="d-flex align-items-center ">
                            <i class="fa-regular fa-circle-check"></i>
                            <p class="ps-2  m-0">Book Publishing</p>
                        </div>
                        <div class="d-flex align-items-center ">
                            <i class="fa-regular fa-circle-check"></i>
                            <p class="ps-2  m-0">Book Cover Design</p>
                        </div>
                    </div>
                </div>
                <div class="sec4-btn sec4-btn-large-screen mt-5">
                    <a href="javascript:;" onclick="document.getElementById('overlayModal').style.display='block'">
                        <button class="header-btn" style="background-color: #0077b5;"><span>Get Started</span></button>
                    </a>
                </div>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-8 col-xs-8 text-center my-3 ">
                <img src="./assets/images/CRAFTING-STORIES-THAT-LEAVE-AN-IMPACT.webp" alt="">
            </div>
            <div class="sec4-btn sec4-btn-small-screen mt-3 ">
                <a href="javascript:;" onclick="document.getElementById('overlayModal').style.display='block'">
                    <button class="header-btn" style="background-color: #0077b5;"><span>Avail 50%
                            Discount</span></button>
                </a>
            </div>
        </div>
        <style>

        </style>
    </div>

    <div class="container py-5">
        <div class="row">
            <div class="col-12">
                <h2 class="text-center">Explore the Works of Our Literary Exhibition</h2>
                <p class="text-center my-3">Enter our literary treasure, where profound feelings are expressed, and
                    information is
                    given a voice. An ideal combination of passion and expertise defines our portfolio.</p>
            </div>
        </div>
        <div class="row book-sec-control justify-content-center mt-4">

            <div class="left-arrowed2"><i class="fa-solid fa-circle-arrow-left"></i></div>
            <div class="right-arrowed2"><i class="fa-solid fa-circle-arrow-right"></i></div>

            <div class="row justify-content-center big-book-sec-slide">
                <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12">
                    <img class="mx-auto" src="./assets/images/book-cover-1.webp" alt="">
                </div>

                <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12">
                    <img class="mx-auto" src="./assets/images/book-cover-2.webp" alt="">
                </div>

                <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12">
                    <img class="mx-auto" src="./assets/images/book-cover-3.webp" alt="">
                </div>

                <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12">
                    <img class="mx-auto" src="./assets/images/book-cover-4.webp" alt="">
                </div>

                <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12">
                    <img class="mx-auto" src="./assets/images/book-cover-5.webp" alt="">
                </div>

                <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12">
                    <img class="mx-auto" src="./assets/images/book-cover-6.webp" alt="">
                </div>

                <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12">
                    <img class="mx-auto" src="./assets/images/book-cover-7.webp" alt="">
                </div>

                <div class="col-lg-3 col-md-4 col-sm-5 col-xs-12">
                    <img class="mx-auto" src="./assets/images/book-cover-8.webp" alt="">
                </div>

            </div>
        </div>
    </div>

    <?php include 'testimonials.php'; ?>

    <div class="container sec4 py-5">
        <div class="row justify-content-center align-items-center ">
            <div class="col-lg-6 col-md-10 col-sm-10 col-xs-10">
                <h2>Expert Authors to Assist You with Book Writing!</h2>
                <div class="para-border-left"></div>
                <p><b class="my-5">Every story is precious, in our view. When you employ our book writers, they will
                        work tirelessly to bring your vision to life. Work and commitment are the only things that will
                        get you somewhere. With these qualities, our book writing services can make a remarkable
                        product. We need the right information to form words into a story. Our book writers ensure that
                        the essence of our words can be understood precisely. Our clients may rest assured that we will
                        never compromise on quality.</b></p>
                <div class="sec4-btn sec4-btn-large-screen mt-5">
                    <a href="javascript:;" onclick="document.getElementById('overlayModal').style.display='block'">
                        <button class="header-btn" style="background-color: #0077b5;"><span>Let's Get
                                Started</span></button>
                    </a>
                </div>
            </div>
            <div class="col-lg-6 col-md-10 col-sm-10 col-xs-10 text-center my-3 ">
                <img src="./assets/images/Expert-Authors-to-Assist.webp" alt="">
            </div>
            <div class="sec4-btn sec4-btn-small-screen mt-3 ">
                <a href="javascript:;" onclick="document.getElementById('overlayModal').style.display='block'">
                    <button class="header-btn" style="background-color: #0077b5;"><span>Let's Get
                            Started</span></button>
                </a>
            </div>
        </div>
    </div>

    <div class="container pb-5 ">
        <div class="row py-4">
            <div class="col-12 ">
                <h2 class="text-center ">Frequently Asked Questions</h2>
                <div class="para-border-center mt-3 "></div>
            </div>
        </div>
        <div class="row justify-content-center align-items-center ">
            <div class="col-lg-8 col-md-9 col-sm-10 col-xs-12">
                <div class="accordion" id="accordionExample">
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                <h5>Why choose Elite Book Writes for book publishing?</h5>
                            </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse show"
                            data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <p>Our professional book writing expert is a leading publishing company known for its
                                    quality and price. We specialize in self- and hybrid publishing for many genres. Our
                                    excellent publishing services and author evaluations make us the best choice for
                                    publishing your story.</p>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                <h5>What genres do Elite Book Writing focus on?</h5>
                            </button>
                        </h2>
                        <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <p>We feel proud of ourselves for serving several genres at Elite Book Writers. Our
                                    dedication to excellence in every area makes us the ideal choice for authors seeking
                                    to expand their creativity.</p>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                <h5>How long does it take to publish a book with Elite Book Writers?</h5>
                            </button>
                        </h2>
                        <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <p>The time frame for publishing the book depends on the project's needs. Our book
                                    writing service is noted for its speed and respect for deadlines. We collaborate
                                    with our writers to publish their books quickly and satisfactorily.</p>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
                                <h5>What are the main benefits of Elite Book publishing services?</h5>
                            </button>
                        </h2>
                        <div id="collapsefour" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <p>Elite Book Writers' book writing services benefit both aspiring and established
                                    writers in many ways. Partnering with us opens doors to benefits like:</p>
                                <ul>
                                    <li>Our professional creative book writers believe every author's journey is unique.
                                        That's why our experienced team provides individualized help throughout the
                                        publishing process.</li>
                                    <li>We know publishing is expensive. This is why we pride ourselves on competitive
                                        and inexpensive prices. Our upfront price lets you plan your publishing path
                                        without surprises.</li>
                                    <li>Elite online book writers prioritize quality. We have the highest editing,
                                        formatting, and cover design standards. Professionals will preserve your
                                        document while improving its readability and appearance.</li>
                                    <li>We specialize in several genres. We grasp genre subtleties and demands to place
                                        your distinctive voice in literature.</li>
                                    <li>Our professional book writing expert understands the importance of achieving
                                        publishing deadlines. Although publishing times vary for each project, Elite
                                        Book Writers is known for its efficiency and devotion to publishing your book
                                        quickly without sacrificing quality.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#collapsefive" aria-expanded="false" aria-controls="collapsefive">
                                <h5>Can you explain your pricing structure?</h5>
                            </button>
                        </h2>
                        <div id="collapsefive" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <p>Our best book writing services are affordable without sacrificing quality. Our
                                    writing, editing, and publishing services are competitively priced. Our expertise
                                    makes publishing accessible to authors of all backgrounds, helping them achieve
                                    their literary goals.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container py-5">
        <div class="row justify-content-around align-items-start ">
            <div class="col-12 pb-2">
                <h1 class="text-center">Let the Literary Universe Be a Reflection of Your Thoughts</h1>
                <p class="text-center"><b>We provide a wide range of best book writing services to meet your needs as an
                        author. Let us guide you on a journey of literary discovery, exploring everything from the
                        visual comic book wonders to the lyrical beauty of poetry.</b></p>
                <div class="text-contact-border mx-auto"></div>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-6 col-sm-10 col-xs-12 mb-3">
                <img class="brands-logos" src="./assets/images/ebook-publishing.webp" alt="">
                <h3>eBook Publishing</h3>
                <div class="para-border-left-95px"></div>
                <p>Join the digital age! We'll style your manuscript for digital readers, guaranteeing your
                    story
                    reaches e-readers and devices around the world.</p>
            </div>

            <div class="col-lg-6 col-md-6 col-sm-10 col-xs-12 mb-3">
                <img class="brands-logos" src="./assets/images/children-book-self-publication.webp" alt="">
                <h3>Childrens Book Self-Publication</h3>
                <div class="para-border-left-95px"></div>
                <p>With online book writers assistance, you may design attractive, imaginative children's books with
                    stunning illustrations that captivate and enchant young readers.</p>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-6 col-sm-10 col-xs-12 mb-3">
                <img class="brands-logos" src="./assets/images/Self-Publication.webp" alt="">
                <h3>Self-Publication</h3>
                <div class="para-border-left-95px"></div>
                <p>Self-publish with us to boost your writing. Control your work's future from writing to distribution
                    and express your unique voice around the world.</p>
            </div>

            <div class="col-lg-6 col-md-6 col-sm-10 col-xs-12 mb-3">
                <img class="brands-logos" src="./assets/images/amazon-publication.webp" alt="">
                <h3>Amazon Publication</h3>
                <div class="para-border-left-95px"></div>
                <p>Amazon publishing lets you get into the world's most excellent online marketplace. We'll help you
                    navigate Amazon to maximize your book's presence and sales.</p>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-6 col-sm-10 col-xs-12 mb-3">
                <img class="brands-logos" src="./assets/images/poetry-book-publication.webp" alt="">
                <h3>Poetry Book Publication</h3>
                <div class="para-border-left-95px"></div>
                <p>Write poetry and share it. Our professional book writers beautifully craft poetry books that touch
                    readers because we understand each verse's feelings.</p>
            </div>

            <div class="col-lg-6 col-md-6 col-sm-10 col-xs-12 mb-3">
                <img class="brands-logos" src="./assets/images/comic-book-self-publication.webp" alt="">
                <h3>Comic Book Self-Publication</h3>
                <div class="para-border-left-95px"></div>
                <p>Experience comic book magic with our self-publishing service. Our creative book writers produce vivid
                    pictures and fantastic tales that expand your imagination.</p>
            </div>
        </div>
    </div>

    <div class="container sec2 py-5">
        <div class="row justify-content-around align-items-start ">
            <div class="col-12 pb-2">
                <h1 class="text-center">Our Results-Driven Publication Process</h1>
                <div class="text-contact-border mx-auto"></div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-5 col-xs-10 text-center py-4">
                <h3>Understanding Your Idea</h3>
                <p>Before starting writing, we carefully listen to your vision. Our team of creative book writers will
                    collaborate to understand your narrative. This phase is the cornerstone of publication.</p>
            </div>

            <div class="col-lg-4 col-md-4 col-sm-5 col-xs-10 text-center py-4">
                <h3>Creating Manuscript</h3>
                <p>Our book writers carefully polish your novel from plot and characters to every word to create a
                    masterpiece that magnetizes readers from the first page.</p>
            </div>

            <div class="col-lg-4 col-md-4 col-sm-5 col-xs-10 text-center py-4">
                <h3>Designing Masterpiece</h3>
                <p>Our professional book writers take the design of covers seriously because it's a book's initial
                    impression. Additionally, we precisely format the inner pages for a smooth reading.</p>
            </div>

            <div class="col-lg-4 col-md-4 col-sm-5 col-xs-10 text-center py-4">
                <h3>Publishers and Distributors</h3>
                <p>The exciting part of book writing service publication begins after your manuscript and design are
                    flawless. Our online book writers want to promote your book worldwide through print and digital
                    platforms.</p>
            </div>

            <div class="col-lg-4 col-md-4 col-sm-5 col-xs-10 text-center py-4">
                <h3>Promotion and Success</h3>
                <p>Writing is just the beginning of your journey. We customize marketing and promotions. We'll help you
                    promote your book, reach your audience, and create buzz around your work.</p>
            </div>
        </div>
    </div>

    <div class="container-fluid ads ads-bottom">
        <div class="ads-bottom-left">
            <img src="./assets/images/ads-bottom-left.webp" alt="">
        </div>
        <div class="ads-bottom-right">
            <img src="./assets/images/ads-bottom-right.webp" alt="">
        </div>
        <div class="container ">
            <div class="row justify-content-center align-items-center">
                <div class="col-12">
                    <h2 class="text-white text-center">Together, We Can Take Your Story to Above and Beyond</h2>
                    <p class="text-white text-center w-75 mx-auto">From the very first word to the very last page,
                        online book writers are here to help you along the way and ensure that your story is told to the
                        best of its potential.</p>
                </div>
                <div class="col-lg-4 col-md-12 col-sm-12 my-2 text-center contact-border">
                    <a href="javascript:;" onclick="document.getElementById('overlayModal').style.display='block'">
                        <button class="header-btn" style="background-color: #0077b5;"><span>Start Writing Book With
                                Us</span></button>
                    </a>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 border-end my-2 text-center contact-border">
                    <a href="tel:+1 213 301 0131">
                        <button class="header-btn tel-btn me-3"><span><i class="fa-solid fa-phone pe-2"></i>Call Us
                                Now</span></button>
                    </a>
                </div>
                <div class="col-lg-4 col-md-12 col-sm-12 my-2 text-center">
                    <a href="javascript:void(Tawk_API.toggle());">
                        <button class="header-btn" style="background-color: #0077b5;"><span>Live Chat</span></button>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>