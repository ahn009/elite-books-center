<?php include 'header.php'; ?>

<section class="container-fluid tandc-banner">
    <div class="home-banner-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <span class="banner-heading text-capitalize">Terms and Conditions</span>
            </div>
        </div>
    </div>
</section>



<section class="makes-sec birth_of py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 ctspriccy">
                <h4 class="themes-h4">Privacy Policy for </h4>
                <h2 class="themes-h2 head-bg">Elite Book Writing Publishing </h2>
                <p class="themes-p">At Elite Book Writing Publishing , accessible from https://elitebookwriters.com/, one
                    of our
                    main priorities is the privacy of our visitors. This Privacy Policy archive contains data
                    gathered and recorded by Elite Book Writing Publishing and its usage.
                </p>

                <p class="themes-p">In case you have extra inquiries or need more data about our Privacy Policy,
                    feel free to contact us.</p>

                <p class="themes-p">The Privacy Policy applies just to our web-based exercises and is essential for
                    guests on site concerning the data they shared or potentially gathered in Elite Book Writing Publishing
                    .
                    This arrangement applies to no data gathered disconnected or by means of channels other than
                    this site.</p>

                <h3>Consent</h3>

                <p class="themes-p">You hereby consent to the terms of our Privacy Policy by using our website.</p>

                <h3>Information we collect</h3>

                <p class="themes-p">The personal data you are required to give, and the justifications for why you
                    are required to give it, will be explained to you at the point we request that you give your own
                    data.</p>

                <p class="themes-p">In the event that you reach us directly, we might get extra data concerning you,
                    for example, your name, telephone number, email address, the items in the message or potentially
                    connections you might disclose, and some other data you might decide to give.</p>

                <p class="themes-p">When you register for an Account, we might request your contact data, among
                    other things, for example, name, address, organization name, email address, and phone number.
                </p>

                <h3>How we use your data</h3>

                <p class="themes-p">We use the collected data in various ways, including to:</p>

                <ul>
                    <li>Improve, personalize, and expand our website</li>
                    <li>Develop new products, services, features, and functionality</li>
                    <li>Send you emails</li>
                    <li>Understand how you use our website</li>
                    <li>Provide, operate, and maintain our website</li>
                    <li>Find and prevent fraud</li>
                    <li>Communicate with you, either straightforwardly or through one of our accomplices, including
                        for client care, to furnish you with refreshes and other data connecting with the site and
                        for advertising and limited time purposes</li>
                </ul>

                <h3>Log Files</h3>

                <p class="themes-p">Elite Book Writing Publishing observes a guideline methodology of utilizing log
                    documents. These said documents log guests when they visit sites. All facilitating
                    establishments do this and are a part of facilitating administrations' checking. The data
                    gathered by log documents incorporates web convention (IP) addresses, program type, Web access
                    Supplier (ISP), date and time stamp, alluding orleave pages, and conceivably the quantity of
                    snaps. These are not connected to any actually recognizable data. The information is used to
                    analyze trends, site administration, track users movement, and gather demographic information.
                </p>

                <h3>Cookies and Web Beacons</h3>

                <p class="themes-p">Like other sites, Elite Book Writing Publishing purposes 'cookies'. The cookies are
                    utilized to store data, remembering guests' inclinations and the pages for the site the guest
                    visited. This data is utilized to streamline the clients' insight by modifying our page content
                    in view of guests' program type and additionally other data.</p>

                <h3>Advertising Partners Privacy Policies</h3>

                <p class="themes-p">You might consult this list to find the Privacy Policy for every one of the
                    promoting accomplices of Elite Book Writing Publishing .</p>

                <p class="themes-p">Note that Elite Book Writing Publishing has no access to or control over third-party
                    advertisers' cookies.</p>

                <h3>Third Party Privacy Policies</h3>

                <p class="themes-p">Elite Book Writing Publishing 's Privacy Policy doesn't matter to different
                    advertisers or
                    websites. In this regard, we encourage you to counsel the particular Privacy Policies of these
                    outsider promotion servers for more detailed data. It mzy incorporate their practices and
                    guidelines about how to quit specific choices.</p>

                <p class="themes-p">Individual browser options can disable cookies. It can be found on the browsers'
                    websites to know more detailed information about cookie management with specific web browsers.
                </p>

                <h3>CCPA Privacy Rights</h3>

                <p class="themes-p">As per the the CCPA , among different rights, California customers reserve the
                    privilege to:</p>

                <p class="themes-p">Demand that a business that gathers a consumer's very own information disclose
                    the classifications and undisclosed bits of personal information that a business has gathered
                    about buyers.</p>

                <p class="themes-p">Request that a business delete/remove any data about the consumer that a
                    business has collected.</p>

                <p class="themes-p">If you wish to make a request, we respond to you in one month. If you would like
                    to employ any of these rights, please contact us.</p>

                <h3>GDPR Data Protection Rights</h3>

                <p class="themes-p">We want to ensure you are completely mindful of each of your information
                    protection rights. Each client is qualified for the accompanying:</p>

                <p class="themes-p">The right to rectification &ndash; You hold the option to demand that we right
                    any data you accept is off base. Additionally, you reserve the right to demand that we complete
                    the data you accept is deficient.</p>

                <p class="themes-p">The right to access &ndash; You reserve the privilege to demand duplicates of
                    your own personal information. </p>

                <p class="themes-p">The right to erasure &ndash; You reserve the privilege to demand that we delete
                    your own information, under specific circumstances.</p>

                <p class="themes-p">The right to processing objection &ndash; You reserve the option to object to
                    our handling of your own information, under specific circumstances.</p>

                <p class="themes-p">The right to restrict processing &ndash; You reserve the right to demand that we
                    restrict the handling of your personal information, under specific circumstances.</p>

                <p class="themes-p">The right to data portability &ndash; You reserve the right to demand that we
                    move the information that we have gathered to another organization, or directly to you, under
                    specific circumstances.</p>

                <p class="themes-p">If you make a request, we respond to you in one month. Should you like to
                    exercise these rights, kindly contact us.</p>

                <h3>Children's Information</h3>

                <p class="themes-p">One more part of our priority list is adding security for kids while using the
                    web. We urge guardians and parents to notice, take part in, or potentially screen and guide
                    their internet-based action.</p>

                <p class="themes-p">Elite Book Writing Publishing intentionally gathers no Personal Identifiable
                    information
                    from kids under 13. In case your child gave this sort of data on our site, we unequivocally urge
                    you to reach us the right away and we will do our earnest attempts to eliminate such data from
                    our records quickly.</p>

                <h3>Refund Policy</h3>

                <p class="themes-p">
                    It is important that you carefully read and understand the refund policies in order to have full
                    knowledge of the privileges and limitations governed by the Elite Book Writing Publishing Policies. We
                    offer refunds only in special cases and specified conditions, detailed as under:
                </p>

                <p class="themes-p">
                    Elite Book Writing Publishing offers a 100% Refund on all its services, however, it is not an
                    unconditional 100% refund and certain conditions still apply.
                </p>

                <p class="themes-p">
                    Elite Book Writing Publishing Refund Policy will be Void if;
                </p>

                <ul>
                    <li>You have chosen a special or a custom package.</li>
                    <li>You have demanded revisions beyond the initial concepts</li>
                    <li>The customer has not been contacted or irresponsive for more than 2 weeks without notice.
                    </li>
                    <li>If the project is placed on hold upon customer request, the refund will be voided. </li>
                    <li>Company’s policies, or policy, have been violated.</li>
                    <li>The creative brief is lacking in required information from the client end.</li>
                    <li>The business is closing or changing its name or business.</li>
                    <li>Reasons such as ‘change of mind’, ‘disagreement with a partner, or other reasons that do not
                        pertain to the service provided will not be subject to refund under any circumstances.</li>
                    <li>Once a client has accepted multiple sets of revisions (for any services), the refund will
                        not be applicable.</li>
                    <li>The customer is entitled to 100% refund before our writers/ editors start working on the
                        project.</li>
                </ul>

                <h2>Errors & Omissions Policy</h2>
                <h3>Approval-Based Model</h3>
                <p class="themes-p">At Elite Book Writing Publishing , we operate under an approval-based model that empowers
                    our valued customers to review their projects before finalization. Once a project receives
                    approval from our clients, it marks the completion of our collaborative efforts, and Elite Book Writing
                    Publishing assumes no responsibility for any subsequent damages. As a token of our commitment to
                    serving our clients to the best of our abilities, we strive to accommodate your needs wherever
                    possible.
                </p>
                <h3>Draft Approval</h3>
                <p class="themes-p">We kindly request all our existing clients to meticulously review the draft
                    provided and, should any corrections, revisions, or changes be deemed necessary, we encourage
                    you to reach out to your dedicated project manager before granting your final approval. While we
                    endeavor to assist with changes and revisions in certain cases, please be aware that these
                    accommodations are extended as a courtesy and are contingent on the specific circumstances. AMZ
                    Elite Book Writing cannot accept liability for any damages incurred once approval is granted.
                </p>
                <h3>Printing</h3>
                <p class="themes-p">Prior to proceeding with the printing of any material, we strongly advise our
                    clients to engage in a thorough review of the drafts provided. Once the printing process is
                    initiated and the material is approved by the client, Elite Book Writing Publishing relinquishes any
                    liability for damages or reprinting expenses. If revisions are required prior to the printing
                    stage, please communicate these changes or revisions directly to your designated Account/Project
                    Manager.
                </p>
                <p class="themes-p">Your understanding of these policies is crucial to ensuring a smooth and
                    mutually beneficial collaboration. We appreciate your trust in Elite Book Writing Publishing , and we are
                    committed to delivering high-quality service to meet your Publishing needs. If you have any
                    questions or require further clarification, please do not hesitate to contact us.
                </p>
                <h3>Disclaimer</h3>

               <p>The logos and trademarks shown on our website belong to the companies whose ownership we acknowledge. Neither these businesses nor their trademarks are associated with us in any way. Using these logos and trademarks in no way indicates that we promote, are affiliated with, or have any relationship with the firms mentioned. Logos and trademarks are the only means of identification that we utilize. This website does not provide legal or financial advice but general information.</p>
            </div>

        </div>
    </div>
</section>


<?php include 'footer.php'; ?>