<div class="container-fluid sec7">
    <div class="container ">
        <div class="row justify-content-center align-items-center">
            <div class="col-12 text-center">
                <div>
                    <h3>Authors' Reviews of Elite Book Writers</h3>
                </div>
                <div class="para-border-center mb-4"></div>
                <i class="fa-solid fa-quote-left"></i>
            </div>
        </div>

        <div class="row justify-content-center align-items-center testimonial-slide w-75 mx-auto">

            <div class="col-lg-7 col-md-7 col-sm-10 col-xs-10 text-center">
                <p class="quotes">I am incredibly grateful to Elite Book Writers for helping me achieve my dream of
                    being a published author. Their reasonably priced book writing bundles changed the game for me as an
                    aspiring writer. Strongly recommended!
                </p>
                <div class="d-flex justify-content-center align-items-center testimonial py-2">
                    <div class="pe-3">
                        <img src="./assets/images/testimonial-1.webp" alt="">
                    </div>
                    <div>
                        <p style="color: #0077b5;">Olivia Audrey</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-7 col-md-7 col-sm-10 col-xs-10 text-center">
                <p class="quotes">Undoubtedly, one of the most outstanding and most reasonably priced book writing
                    services I've dealt with is Elite Book Writers. Their services are of the highest caliber, and their
                    packages are affordable. Now, my ideal book is a reality!</p>
                <div class="d-flex justify-content-center align-items-center testimonial py-2">
                    <div class="pe-3">
                        <img src="./assets/images/testimonial-2.webp" alt="">
                    </div>
                    <div>
                        <p style="color: #0077b5;">William Theodore</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-7 col-md-7 col-sm-10 col-xs-10 text-center">
                <p class="quotes">I had many options when I first started writing, but Elite Book Writers stood out. The
                    process went well thanks to their reasonably priced packages and individualized support. They are
                    undoubtedly among the most extraordinary possibilities for beginning writers to write books.</p>
                <div class="d-flex justify-content-center align-items-center testimonial py-2">
                    <div class="pe-3">
                        <img src="./assets/images/testimonial-3.webp" alt="">
                    </div>
                    <div>
                        <p style="color: #0077b5;">Florence Georgina</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>