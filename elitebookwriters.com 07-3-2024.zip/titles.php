<?php

$uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri_segments = explode('/', $uri_path);
?>

<?php if ($uri_segments[1] == '') { ?>

    <title>Book Writing | Elite Book Writers</title>
    <!-- <meta name="description" content=""> -->
    <!-- <meta name="Keywords" content=""> -->
    <link rel="canonical" href="https://elitebookwriters.com/" />
    <link rel="alternate" href="https://elitebookwriters.com/" hreflang="en-us" />

<?php } else if ($uri_segments[1] == 'ghost-writing.php') { ?>

    <title>Ghost Writing | Elite Book Writers</title>
    <!-- <meta name="description" content=""> -->
    <!-- <meta name="Keywords" content=""> -->
    <link rel="canonical" href="https://elitebookwriters.com/ghost-writing.php" />
    <link rel="alternate" href="https://elitebookwriters.com/ghost-writing.php" hreflang="en-us" />

<?php } else if ($uri_segments[1] == 'book-marketing.php') { ?>

    <title>Book Marketing | Elite Book Writers</title>
    <!-- <meta name="description" content=""> -->
    <!-- <meta name="Keywords" content=""> -->
    <link rel="canonical" href="https://elitebookwriters.com/book-marketing.php" />
    <link rel="alternate" href="https://elitebookwriters.com/book-marketing.php" hreflang="en-us" />

<?php } else if ($uri_segments[1] == 'book-publishing.php') { ?>

    <title>Book Publishing | Elite Book Writers </title>
    <!-- <meta name="description" content=""> -->
    <!-- <meta name="Keywords" content=""> -->
    <link rel="canonical" href="https://elitebookwriters.com/book-publishing.php" />
    <link rel="alternate" href="https://elitebookwriters.com/book-publishing.php" hreflang="en-us" />

<?php } else if ($uri_segments[1] == 'book-cover-design.php') { ?>

    <title>Book Cover Design | Elite Book Writers</title>
    <!-- <meta name="description" content=""> -->
    <!-- <meta name="Keywords" content=""> -->
    <link rel="canonical" href="https://elitebookwriters.com/book-cover-design.php" />
    <link rel="alternate" href="https://elitebookwriters.com/book-cover-design.php" hreflang="en-us" />

<?php } else if ($uri_segments[1] == 'about.php') { ?>

    <title>About Us | Elite Book Writers</title>
    <link rel="canonical" href="https://elitebookwriters.com/about.php" />
    <link rel="alternate" href="https://elitebookwriters.com/about.php" hreflang="en-us" />

<?php } else if ($uri_segments[1] == 'terms-and-condition.php') { ?>

    <title>Terms & Condition | Elite Book Writers</title>
    <link rel="canonical" href="https://elitebookwriters.com/terms-and-condition.php" />
    <link rel="alternate" href="https://elitebookwriters.com/terms-and-condition.php" hreflang="en-us" />

<?php } else if ($uri_segments[1] == 'thank-you.php') { ?>

    <title>Thank You | Elite Book Writers</title>
    <link rel="canonical" href="https://elitebookwriters.com/thank-you.php" />
    <link rel="alternate" href="https://elitebookwriters.com/thank-you.php" hreflang="en-us" />

<?php } else if ($uri_segments[1] == 'contact.php') { ?>

    <title>Contact Us | Elite Book Writers</title>
    <link rel="canonical" href="https://elitebookwriters.com/contact.php" />
    <link rel="alternate" href="https://elitebookwriters.com/contact.php" hreflang="en-us" />

<?php } ?>