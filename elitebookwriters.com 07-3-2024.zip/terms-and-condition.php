<?php include 'header.php'; ?>

<section class="container-fluid tandc-banner">
    <div class="home-banner-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <span class="banner-heading text-capitalize">Terms and Conditions</span>
            </div>
        </div>
    </div>
</section>


<section class="container-fluid section-banner pt-5 ">
    <div class="container">
        <div class="row justify-content-center ">
            <div class="col-lg-9 col-md-10 col-sm-11 col-xs-12 text-capital">
                <h3>Term and Condition</h3>
                <div class="para-border-left"></div>
                <p>Place an order with us, i.e., making a payment, constitutes your acknowledgment and acceptance of the below terms and conditions.</p>
                <br>

                <h3>Copyright & Personal Use</h3>
                <div class="para-border-left"></div>
                <p>All of the Products that You Receive Are 100% Original. You, and you alone, own all copyrights to the Products and any other items provided to you. You are obligated to protect, defend, and hold the Company harmless if you make any unlawful use of any material that the Company has made available to you. Criminal and civil penalties may be imposed upon you for illegally using the provided Products or this Website content.</p>
                <br>

                <h3>No Plagiarism</h3>
                <div class="para-border-left"></div>
                <p>Whether it's intentional or not, we will not tolerate, promote, or engage in dishonest practices like plagiarism. Copyright laws are extremely important to us, and we will not tolerate any form of customer-initiated plagiarism or violation of copyright laws in any way.</p>
                <p>It is important to note that the Company, its affiliates, and partners are not responsible for any improper, unlawful, unethical, or otherwise wrongful use of the Products or any other written content obtained from our website. Plagiarism, litigation, low grades, expulsion, academic probation, scholarship, award, prize, title, position loss, failure, suspension, or any other form of disciplinary or legal action falls under this category. The purchaser of content from our website is fully liable for any disciplinary measures that may be taken due to the inappropriate, immoral, or unlawful use of that content.</p>
                <br>

                <h3>Our policy for using images</h3>
                <div class="para-border-left"></div>
                <p>We do not use copyrighted images on our own since we do not hold pictures' copyright unless our in-house illustrators expressly make them. So that you may copy and paste the images on your own, we will give you the URLs to our recommendations. You can use royalty-free photographs without worrying about paying the owner(s). However, if the images have a copyright, you could need to pay them.</p>
                <br>

                <h3>Refund Policy</h3>
                <div class="para-border-left"></div>
                <p>If you want to know all the ins and outs of the Elite Book Writers Policies, including the return policies, you should study them thoroughly. Here are the specific situations and criteria under which we provide refunds:</p>
                <p>All Elite Book Writing services have a 100% money-back guarantee, but some restrictions and limitations exist.</p>
                <p>This refund policy of Elite Book Writers is null and void if</p>
                <ul>
                    <li>You have selected a unique or personalized bundle.</li>
                    <li>You have insisted on changes that go beyond the original ideas.</li>
                    <li>More than two weeks have passed with no communication or response from the client.</li>
                    <li>The customer's desire to halt the project will result in the cancellation of the reimbursement.</li>
                    <li>Someone has broken the rules set out by the company.</li>
                    <li>The client-side information needed for the creative brief is missing.</li>
                    <li>The company is going through a name change or closure.</li>
                    <li>Under no circumstances will you be refunded for reasons like "change of mind" or "disagreement with a partner," which have nothing to do with the service itself.</li>
                    <li>The refund policy does not apply once a client has agreed to many rounds of revisions for any service.</li>
                </ul>
                <br>

                <h3>Limitations on Revisions</h3>
                <div class="para-border-left"></div>
                <p>Revisions will be made to the modified content to remove any remaining technical or objective mistakes per your editing order. Additional modifications to the content will be made at the Company's sole discretion if no technical or objective errors are found.</p>
                <p>In the case of writing orders, we will make revisions to shorter sections of text until the client gives their final approval. Any changes made to the content after the client approves will be charged the applicable editing fee.</p>
                <br>

                <h3>Amendments</h3>
                <div class="para-border-left"></div>
                <p>You understand and consent to our having the right to alter the Terms and Conditions and the Privacy Policy unilaterally. It is advised that you periodically review both pages because this portion of our website will be updated to reflect any changes that may be made.</p>
                <br>

                <h3>Contacting Us</h3>
                <div class="para-border-left"></div>
                <p>If you have any queries regarding our policies, you may send an email to: info@elitebookwriters.com</p>
                <br>

                <h3>Disclaimer</h3>
                <div class="para-border-left"></div>
                <p>The logos and trademarks shown on our website belong to the companies whose ownership we acknowledge. Neither these businesses nor their trademarks are associated with us in any way. Using these logos and trademarks in no way indicates that we promote, are affiliated with, or have any relationship with the firms mentioned. Logos and trademarks are the only means of identification that we utilize. This website does not provide legal or financial advice but general information.</p>
                <br>
            </div>
        </div>
    </div>

    <div class="container-fluid ads ads-bottom">
        <div class="ads-bottom-left">
            <img src="./assets/images/ads-bottom-left.webp" alt="">
        </div>
        <div class="ads-bottom-right">
            <img src="./assets/images/ads-bottom-right.webp" alt="">
        </div>
        <div class="container ">
            <div class="row justify-content-center align-items-center">
                <div class="col-12">
                    <h2 class="text-white text-center">Call Now for an In-depth Consultation!</h2>
                    <p class="text-white text-center w-75 mx-auto">For All-Inclusive Book Writing Assistance, Get in Touch Now!</p>
                </div>
                <div class="col-lg-4 col-md-12 col-sm-12 my-2 text-center contact-border">
                    <a href="javascript:;" onclick="document.getElementById('overlayModal').style.display='block'">
                        <button class="header-btn" style="background-color: #0f3051;">Get Started</button>
                    </a>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 border-end my-2 text-center contact-border">
                    <a href="tel:+1 213 301 0131"
                        class="me-3 header-tel-btn d-flex justify-content-center align-items-center">
                        <!-- <img src="./assets/images/us-flag.svg" class="me-1 us-flag" alt=""> -->
                        <i class="fa-solid fa-phone pe-2"></i>+1 213 301 0131
                    </a>
                </div>
                <div class="col-lg-4 col-md-12 col-sm-12 my-2 text-center">
                    <a href="javascript:void(0);" onclick="tidioChatApi.open()">
                        <button class="header-btn" style="background-color: #0f3051;">Live Chat</button>
                    </a>
                </div>
            </div>
        </div>
    </div>

</section>

<?php include 'footer.php'; ?>